Version 1.0
Created by Mauler
Administrator
Mauler@Multiplayerforums.com

===FILE===

This pack contains the files necessary to add sidebar/icons into your custom 4.1 maps
and includes in "example_tt.ini" file for your use in your per map "C&C_MYMAP_tt.ini"

This file is mainly for modders!

===Install===

Extract all DDS files to a Directory and simple rename
the "example_tt.ini" to match your per map ini..

Also place the DDS files into your custom MIX file if you are using the sidebar support in TT 4.1